#!/bin/bash

#conda environment with the following requirements for running ExInator2 Functional Impact Analysis

#conda create -n ex2_fi -c genomedk -c bioconda -c conda-forge bedtools=2.26.0 r-base=3.5.1 python=3.6 regex numpy pytabix epacts=3.4.2

cd "${0%/*}"
start=`date +%s`

python /home/Exinator2/functionalimpact_script_main.py -c 1 -i 100 \
-m /home/Exinator2/Inputs/Biliary-AdenoCA.bed -o /home/Exinator2/Output_FI \
-g /home/Exinator2/Inputs/gencode.v19.long_noncoding_RNAs.gtf \
-f /home/Exinator2/Inputs/Genome_v19.fasta -z /home/Exinator2/Inputs/chromosomes_tab.bed \
-s /home/Exinator2/Inputs/whole_genome_SNVs.tsv.gz -t /home/Exinator2/Inputs/CLC2_final_extended.txt \
-e /home/Exinator2/Inputs/black_list_regions_final.bed

end=`date +%s`
runtime=$((end-start))
echo "$INPUT $((runtime/60)) minutes" >> out_lncRNA_gencode.txt
