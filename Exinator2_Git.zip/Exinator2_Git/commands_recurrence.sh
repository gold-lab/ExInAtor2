#!/bin/bash

#conda create -n ex2_recurrence -c bioconda -c conda-forge bedtools=2.29.2 r-base=3.5.1 python=3.6 regex numpy

cd "${0%/*}"
start=`date +%s`

python /home/Exinator2/recurrence_script_main.py -b 10000 -f /home/Exinator2/Inputs/Genome_v19.fasta \
-o /home/Exinator2/Output_REC -g /home/Exinator2/Inputs/gencode.v19.long_noncoding_RNAs.gtf -i /home/Exinator2/Inputs/Biliary-AdenoCA.bed \
-k /home/Exinator2/Inputs/3mers.txt -w /home/Exinator2/Inputs/gencode.v19.annotation.gtf -z /home/Exinator2/Inputs/chromosomes_tab.bed \
-t /home/Exinator2/Inputs/CLC2_final_extended.txt -y /home/Exinator2/Inputs/chromosomes_long_tab.bed -e /home/Exinator2/Inputs/black_list_regions_final.bed -s 100

end=`date +%s`
runtime=$((end-start))
echo "$INPUT $((runtime/60)) minutes" >> out_lncRNA_gencode.txt
